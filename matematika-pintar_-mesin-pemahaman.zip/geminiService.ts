
import { GoogleGenAI, Type } from "@google/genai";
import { LessonContent, Grade } from "./types";

const MASTER_PROMPT_SYSTEM = `
Kamu adalah tim ahli pendidikan matematika Indonesia (Guru SD-SMP, Instructional Designer).
Tujuan: Membuat materi matematika yang sangat mudah dipahami, fokus pada "MENGAPA" bukan sekadar "JAWABAN".
Bahasa: Indonesia sederhana, ramah anak, suportif.
Prinsip: Gunakan analogi dunia nyata, hindari istilah teknis berat di awal.

STRUKTUR WAJIB:
1. Cerita Kontekstual (Masalah Nyata)
2. Penjelasan Konsep Inti (Tanpa rumus dulu)
3. Visual & Animasi (Deskripsi)
4. Rumus (Setelah paham konsep)
5. Contoh Soal Bertahap (Mudah, Sedang, Menantang)
6. Kesalahan Umum & Miskonsepsi
7. Latihan Adaptif (5-10 soal pilihan ganda)
8. Mini Game Edukatif (Konsep game)
9. Refleksi & Rangkuman
`;

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    grade: { type: Type.STRING },
    classLevel: { type: Type.STRING },
    contextualStory: {
      type: Type.OBJECT,
      properties: {
        story: { type: Type.STRING },
        triggerQuestion: { type: Type.STRING }
      },
      required: ["story", "triggerQuestion"]
    },
    coreConcept: {
      type: Type.OBJECT,
      properties: {
        explanation: { type: Type.ARRAY, items: { type: Type.STRING } },
        analogy: { type: Type.STRING }
      },
      required: ["explanation", "analogy"]
    },
    visualDescription: { type: Type.STRING },
    formula: {
      type: Type.OBJECT,
      properties: {
        latex: { type: Type.STRING },
        explanation: { type: Type.STRING },
        whenToUse: { type: Type.STRING }
      },
      required: ["latex", "explanation", "whenToUse"]
    },
    examples: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          difficulty: { type: Type.STRING },
          question: { type: Type.STRING },
          steps: { type: Type.ARRAY, items: { type: Type.STRING } }
        }
      }
    },
    commonErrors: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          error: { type: Type.STRING },
          reason: { type: Type.STRING },
          solution: { type: Type.STRING }
        }
      }
    },
    adaptiveQuiz: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          level: { type: Type.STRING },
          question: { type: Type.STRING },
          options: { type: Type.ARRAY, items: { type: Type.STRING } },
          correctIndex: { type: Type.NUMBER },
          explanation: { type: Type.STRING }
        }
      }
    },
    miniGame: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING },
        concept: { type: Type.STRING },
        rules: { type: Type.STRING },
        gameplay: { type: Type.STRING }
      }
    },
    reflection: {
      type: Type.OBJECT,
      properties: {
        summary: { type: Type.ARRAY, items: { type: Type.STRING } },
        keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
        motivation: { type: Type.STRING }
      }
    }
  },
  required: ["title", "grade", "classLevel", "contextualStory", "coreConcept", "formula", "examples", "commonErrors", "adaptiveQuiz", "miniGame", "reflection"]
};

// Function to generate lesson content using Gemini API
export const generateMathContent = async (
  grade: Grade, 
  level: string, 
  topic: string, 
  performanceContext: string = ""
): Promise<LessonContent> => {
  // Always use process.env.API_KEY directly as per guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Buatkan materi matematika Tingkat: ${grade} Kelas: ${level} Materi: ${topic}.
    Konteks Siswa: ${performanceContext || "Siswa baru mulai belajar topik ini."}
    Jika konteks menyebutkan siswa kesulitan, buat penjelasan yang jauh lebih sederhana dengan lebih banyak analogi.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction: MASTER_PROMPT_SYSTEM,
      responseMimeType: "application/json",
      responseSchema: RESPONSE_SCHEMA
    }
  });

  // response.text is a property, not a function
  return JSON.parse(response.text || '{}');
};

// Function to generate teacher report using Gemini API
export const generateTeacherReport = async (progress: any) => {
    // Always use process.env.API_KEY directly as per guidelines
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analisis data progres siswa berikut dan berikan rekomendasi pengajaran untuk guru: ${JSON.stringify(progress)}`
    });
    // response.text is a property, not a function
    return response.text;
}
