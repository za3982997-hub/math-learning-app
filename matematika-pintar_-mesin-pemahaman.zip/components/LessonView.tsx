
import React, { useState, useEffect } from 'react';
import { LessonContent } from '../types';
import { 
  ChevronRight, ChevronLeft, BookOpen, Lightbulb, Play, 
  Layers, HelpCircle, AlertTriangle, CheckCircle, Target, 
  Award, Sparkles, XCircle 
} from 'lucide-react';

interface LessonViewProps {
  content: LessonContent;
  onComplete: () => void;
}

const LessonView: React.FC<LessonViewProps> = ({ content, onComplete }) => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    { id: 'story', label: 'Cerita', icon: BookOpen, color: 'indigo' },
    { id: 'concept', label: 'Konsep', icon: Lightbulb, color: 'amber' },
    { id: 'visual', label: 'Visual', icon: Play, color: 'emerald' },
    { id: 'formula', label: 'Rumus', icon: Layers, color: 'blue' },
    { id: 'examples', label: 'Contoh', icon: HelpCircle, color: 'purple' },
    { id: 'errors', label: 'Waspada', icon: AlertTriangle, color: 'rose' },
    { id: 'quiz', label: 'Latihan', icon: CheckCircle, color: 'emerald' },
    { id: 'game', label: 'Game', icon: Target, color: 'indigo' },
    { id: 'reflection', label: 'Rangkuman', icon: Award, color: 'yellow' },
  ];

  const nextStep = () => {
    if (activeStep < steps.length - 1) setActiveStep(activeStep + 1);
    else onComplete();
  };

  const prevStep = () => {
    if (activeStep > 0) setActiveStep(activeStep - 1);
  };

  const renderContent = () => {
    switch (steps[activeStep].id) {
      case 'story':
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center gap-3">
               <div className="p-3 bg-indigo-100 text-indigo-600 rounded-2xl"><BookOpen size={24} /></div>
               <h2 className="text-2xl font-black text-indigo-900">Mari Berimajinasi...</h2>
            </div>
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border-l-8 border-indigo-500 leading-relaxed text-xl text-gray-700 italic">
              "{content.contextualStory.story}"
            </div>
            <div className="bg-indigo-50 p-8 rounded-[2.5rem] border-2 border-dashed border-indigo-200">
              <p className="text-2xl font-black text-indigo-700 flex items-start gap-3">
                 <Sparkles className="shrink-0 mt-1" /> {content.contextualStory.triggerQuestion}
              </p>
            </div>
          </div>
        );
      case 'concept':
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="flex items-center gap-3">
               <div className="p-3 bg-amber-100 text-amber-600 rounded-2xl"><Lightbulb size={24} /></div>
               <h2 className="text-2xl font-black text-amber-900">Apa Sih Konsepnya?</h2>
            </div>
            <div className="grid gap-4">
              {content.coreConcept.explanation.map((item, i) => (
                <div key={i} className="bg-white p-6 rounded-[1.5rem] shadow-sm border border-gray-100 flex items-start gap-4 hover:border-amber-200 transition-colors">
                  <div className="bg-amber-100 text-amber-600 font-black rounded-xl h-10 w-10 flex items-center justify-center shrink-0">{i + 1}</div>
                  <p className="text-gray-700 text-lg leading-relaxed">{item}</p>
                </div>
              ))}
            </div>
            <div className="bg-amber-50 p-8 rounded-[2.5rem] border border-amber-200">
              <h3 className="font-black text-amber-800 mb-3 text-lg flex items-center gap-2">
                <Sparkles size={20} /> Analogi Menarik:
              </h3>
              <p className="text-amber-900/80 leading-relaxed text-lg">{content.coreConcept.analogy}</p>
            </div>
          </div>
        );
      case 'visual':
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
               <div className="p-3 bg-emerald-100 text-emerald-600 rounded-2xl"><Play size={24} /></div>
               <h2 className="text-2xl font-black text-emerald-900">Lihat Simulasinya</h2>
            </div>
            <div className="aspect-video bg-slate-900 rounded-[3rem] shadow-2xl flex items-center justify-center p-12 text-center group cursor-pointer overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-t from-emerald-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative z-10">
                <div className="bg-emerald-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(16,185,129,0.4)] group-hover:scale-110 transition-transform">
                  <Play className="w-10 h-10 text-white fill-white ml-1" />
                </div>
                <p className="text-gray-300 text-xl font-medium max-w-lg mx-auto leading-relaxed">{content.visualDescription}</p>
                <div className="mt-8 text-[10px] text-emerald-400 font-black uppercase tracking-[0.3em] opacity-50">Visualisasi Konsep Interaktif</div>
              </div>
            </div>
          </div>
        );
      case 'formula':
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
               <div className="p-3 bg-blue-100 text-blue-600 rounded-2xl"><Layers size={24} /></div>
               <h2 className="text-2xl font-black text-blue-900">Bahasa Matematikanya</h2>
            </div>
            <div className="bg-white p-12 rounded-[3rem] shadow-sm border border-blue-50 flex items-center justify-center">
              <code className="text-5xl font-mono text-blue-700 font-black">{content.formula.latex}</code>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-blue-50 p-8 rounded-[2rem] border border-blue-100">
                <h3 className="font-black text-blue-800 mb-3">Apa Arti Simbol Ini?</h3>
                <p className="text-blue-900/70 leading-relaxed">{content.formula.explanation}</p>
              </div>
              <div className="bg-emerald-50 p-8 rounded-[2rem] border border-emerald-100">
                <h3 className="font-black text-emerald-800 mb-3">Gunakan Saat:</h3>
                <p className="text-emerald-900/70 leading-relaxed">{content.formula.whenToUse}</p>
              </div>
            </div>
          </div>
        );
      case 'examples':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-purple-900">Latihan Bertahap</h2>
            <div className="space-y-6">
              {content.examples.map((ex, i) => (
                <div key={i} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-purple-50 hover:shadow-xl hover:-translate-y-1 transition-all">
                  <div className="flex items-center gap-3 mb-6">
                    <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${ex.difficulty === 'Mudah' ? 'bg-green-100 text-green-700' : ex.difficulty === 'Sedang' ? 'bg-orange-100 text-orange-700' : 'bg-rose-100 text-rose-700'}`}>
                      {ex.difficulty}
                    </span>
                    <h3 className="font-black text-gray-400 text-sm">CONTOH {i + 1}</h3>
                  </div>
                  <p className="text-xl font-black text-gray-900 mb-8 leading-relaxed">"{ex.question}"</p>
                  <div className="space-y-4">
                    {ex.steps.map((step, si) => (
                      <div key={si} className="flex gap-4 items-start">
                        <div className="h-6 w-6 bg-purple-50 text-purple-600 rounded-full flex items-center justify-center text-xs font-black shrink-0 mt-1">{si + 1}</div>
                        <p className="text-gray-600 leading-relaxed">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'errors':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-rose-900 flex items-center gap-3">
              <AlertTriangle className="text-rose-500" /> Hati-hati Terjebak!
            </h2>
            <div className="grid gap-6">
              {content.commonErrors.map((err, i) => (
                <div key={i} className="bg-rose-50 p-8 rounded-[2.5rem] border border-rose-100 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-125 transition-transform duration-700">
                    <XCircle size={100} />
                  </div>
                  <h3 className="font-black text-rose-800 text-lg mb-2 flex items-center gap-2">
                    Kesalahan: {err.error}
                  </h3>
                  <p className="text-rose-900/60 text-sm mb-6 font-medium italic">"Mungkin kamu mengira: {err.reason}"</p>
                  <div className="bg-white p-5 rounded-2xl shadow-sm border border-emerald-100 flex items-center gap-4">
                     <div className="h-10 w-10 bg-emerald-500 text-white rounded-xl flex items-center justify-center shrink-0">
                        <CheckCircle size={24} />
                     </div>
                     <p className="text-emerald-900 font-bold">Lakukan Ini: {err.solution}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'quiz':
        return <QuizView quizItems={content.adaptiveQuiz} />;
      case 'game':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-indigo-900">Arena Bermain: {content.miniGame.name}</h2>
            <div className="bg-indigo-900 text-white p-12 rounded-[3rem] shadow-2xl relative overflow-hidden min-h-[400px] flex flex-col justify-center">
              <div className="absolute top-0 right-0 p-8 opacity-10 rotate-12">
                <Target size={240} />
              </div>
              <div className="relative z-10">
                <div className="bg-white/10 w-fit px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest mb-6 border border-white/20">Misi Kamu</div>
                <p className="text-2xl font-black mb-10 leading-relaxed text-indigo-100">{content.miniGame.gameplay}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white/5 p-6 rounded-3xl border border-white/10 backdrop-blur-sm">
                    <span className="block font-black text-indigo-300 text-[10px] uppercase mb-2">Konsep Matematika</span>
                    <p className="text-sm font-medium">{content.miniGame.concept}</p>
                  </div>
                  <div className="bg-white/5 p-6 rounded-3xl border border-white/10 backdrop-blur-sm">
                    <span className="block font-black text-indigo-300 text-[10px] uppercase mb-2">Aturan Main</span>
                    <p className="text-sm font-medium">{content.miniGame.rules}</p>
                  </div>
                </div>
              </div>
            </div>
            <button className="w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black text-xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 active:scale-[0.98]">
              Mulai Game Sekarang! 🚀
            </button>
          </div>
        );
      case 'reflection':
        return (
          <div className="space-y-10 animate-in zoom-in duration-500 pb-12">
            <div className="text-center space-y-4">
              <div className="inline-block p-6 bg-yellow-100 rounded-full text-yellow-600 mb-2">
                <Award size={64} className="animate-bounce" />
              </div>
              <h2 className="text-4xl font-black text-slate-900 tracking-tighter">Level Up! Kamu Paham.</h2>
              <p className="text-slate-500 text-lg font-medium">Inilah bekal ilmu yang baru saja kamu dapatkan</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
               <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 space-y-6">
                  <h3 className="font-black text-slate-900 text-xl flex items-center gap-3">
                    <div className="h-3 w-3 bg-indigo-500 rounded-full"></div> Rangkuman Inti
                  </h3>
                  <ul className="space-y-4">
                    {content.reflection.summary.map((s, i) => (
                      <li key={i} className="text-slate-600 font-medium flex gap-4 items-start">
                        <div className="h-6 w-6 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center shrink-0 mt-0.5"><CheckCircle size={14} /></div>
                        {s}
                      </li>
                    ))}
                  </ul>
               </div>

               <div className="space-y-6">
                  <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white">
                    <h3 className="font-black text-amber-400 mb-4 uppercase text-xs tracking-widest">3 Poin Kunci</h3>
                    <div className="space-y-3">
                      {content.reflection.keyPoints.map((kp, i) => (
                        <div key={i} className="bg-white/10 p-4 rounded-2xl font-bold flex gap-4 items-center">
                          <span className="text-amber-400">#0{i + 1}</span> {kp}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-indigo-600 p-8 rounded-[2.5rem] text-center italic text-indigo-100 font-bold text-lg">
                    "{content.reflection.motivation}"
                  </div>
               </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto pb-32">
      {/* Course Header */}
      <div className="mb-12 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <button 
            onClick={() => window.location.reload()}
            className="mb-4 text-slate-400 font-bold text-xs flex items-center gap-2 hover:text-indigo-600 transition-colors"
          >
            <ChevronLeft size={14} /> Kembali ke Beranda
          </button>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-indigo-100 text-indigo-700 font-black text-[10px] px-3 py-1 rounded-full uppercase tracking-tighter">{content.grade} {content.classLevel}</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">{content.title}</h1>
        </div>
        <div className="w-full md:w-auto text-right">
          <div className="flex justify-between md:justify-end gap-10 mb-2">
             <div className="text-right">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pelajaran</div>
                <div className="text-sm font-black text-slate-900 uppercase">Tahap {activeStep + 1} / {steps.length}</div>
             </div>
             <div className="text-right">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Hadiah</div>
                <div className="text-sm font-black text-emerald-600">+200 XP</div>
             </div>
          </div>
          <div className="w-full md:w-48 h-2.5 bg-slate-200 rounded-full overflow-hidden shadow-inner">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-700 ease-out shadow-[0_0_15px_rgba(99,102,241,0.5)]" 
              style={{ width: `${((activeStep + 1) / steps.length) * 100}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Navigation Pills */}
      <div className="flex overflow-x-auto gap-3 pb-6 mb-12 no-scrollbar scroll-smooth">
        {steps.map((step, i) => {
          const Icon = step.icon;
          const isActive = activeStep === i;
          const isDone = activeStep > i;
          return (
            <button
              key={step.id}
              onClick={() => setActiveStep(i)}
              className={`flex items-center gap-3 px-6 py-3 rounded-2xl whitespace-nowrap transition-all duration-300 border-2 ${
                isActive 
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xl shadow-indigo-100' 
                  : isDone 
                    ? 'bg-white text-indigo-600 border-indigo-50 shadow-sm' 
                    : 'bg-white text-slate-300 border-slate-50'
              }`}
            >
              <Icon size={18} className={isActive ? 'animate-pulse' : ''} />
              <span className="text-sm font-black uppercase tracking-tight">{step.label}</span>
              {isDone && <CheckCircle size={14} className="ml-1" />}
            </button>
          );
        })}
      </div>

      {/* Content Area */}
      <div className="min-h-[500px]">
        {renderContent()}
      </div>

      {/* Persistent Nav Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-6 md:p-8 bg-white/90 backdrop-blur-xl border-t border-slate-100 z-50">
        <div className="max-w-4xl mx-auto flex justify-between gap-4 md:gap-8">
          <button
            onClick={prevStep}
            disabled={activeStep === 0}
            className={`flex-1 py-5 px-6 rounded-3xl font-black flex items-center justify-center gap-3 border-4 transition-all ${
              activeStep === 0 ? 'border-slate-50 text-slate-200' : 'border-slate-100 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <ChevronLeft size={24} /> <span className="hidden md:inline">Kembali</span>
          </button>
          <button
            onClick={nextStep}
            className="flex-[2] py-5 px-6 bg-indigo-600 text-white rounded-3xl font-black text-lg flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all active:scale-[0.97] shadow-2xl shadow-indigo-100"
          >
            {activeStep === steps.length - 1 ? 'Selesaikan Misi!' : 'Lanjut Tahap Berikutnya'} <ChevronRight size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};

const QuizView: React.FC<{ quizItems: LessonContent['adaptiveQuiz'] }> = ({ quizItems }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    setIsCorrect(idx === quizItems[currentIdx].correctIndex);
  };

  const nextQuestion = () => {
    if (currentIdx < quizItems.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setSelected(null);
      setIsCorrect(null);
    }
  };

  const item = quizItems[currentIdx];

  return (
    <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Uji Pemahaman</h2>
          <p className="text-slate-500">AI menyesuaikan tingkat kesulitan untukmu.</p>
        </div>
        <div className="text-right">
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Pertanyaan</span>
           <div className="text-2xl font-black text-indigo-600">{currentIdx + 1} / {quizItems.length}</div>
        </div>
      </div>
      
      <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100">
        <div className="mb-6">
          <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm ${item.level === 'Mudah' ? 'bg-green-500 text-white' : item.level === 'Sedang' ? 'bg-amber-500 text-white' : 'bg-rose-500 text-white'}`}>
            Level: {item.level}
          </span>
        </div>
        <p className="text-2xl font-black text-slate-800 mb-12 leading-relaxed">"{item.question}"</p>
        
        <div className="grid gap-4">
          {item.options.map((opt, i) => {
            const isCorrectAnswer = i === item.correctIndex;
            const isUserSelected = selected === i;
            
            let colorClass = "bg-slate-50 border-slate-100 text-slate-700 hover:border-indigo-300 hover:bg-white";
            if (selected !== null) {
              if (isCorrectAnswer) colorClass = "bg-emerald-500 border-emerald-500 text-white shadow-xl shadow-emerald-100";
              else if (isUserSelected) colorClass = "bg-rose-500 border-rose-500 text-white shadow-xl shadow-rose-100";
              else colorClass = "bg-slate-50 border-slate-50 text-slate-300";
            }

            return (
              <button
                key={i}
                onClick={() => handleAnswer(i)}
                className={`p-6 rounded-3xl text-left font-bold text-lg transition-all border-4 relative overflow-hidden group ${colorClass}`}
              >
                <div className="flex justify-between items-center relative z-10">
                  <span>{opt}</span>
                  {selected !== null && isCorrectAnswer && <CheckCircle size={28} />}
                  {selected !== null && isUserSelected && !isCorrectAnswer && <XCircle size={28} />}
                </div>
                {selected === null && (
                   <div className="absolute right-6 opacity-0 group-hover:opacity-10 transition-opacity">
                      <ChevronRight size={40} />
                   </div>
                )}
              </button>
            );
          })}
        </div>

        {selected !== null && (
          <div className="mt-12 animate-in slide-in-from-top-6 duration-500">
            <div className={`p-8 rounded-[2rem] border-4 ${isCorrect ? 'bg-emerald-50 border-emerald-100 text-emerald-900' : 'bg-rose-50 border-rose-100 text-rose-900'}`}>
              <h4 className="font-black text-xl mb-3 flex items-center gap-3">
                {isCorrect ? <Sparkles size={24} className="text-emerald-500" /> : <AlertTriangle size={24} className="text-rose-500" />}
                {isCorrect ? 'Kamu Pintar!' : 'Belum Tepat, Tidak Apa!'}
              </h4>
              <p className="text-lg leading-relaxed font-medium opacity-80">{item.explanation}</p>
            </div>
            {currentIdx < quizItems.length - 1 && (
              <button 
                onClick={nextQuestion}
                className="mt-6 w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black text-lg hover:bg-black transition-all shadow-xl shadow-slate-200"
              >
                Lanjutkan Ke Pertanyaan Berikutnya
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default LessonView;
