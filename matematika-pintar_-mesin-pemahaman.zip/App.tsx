
import React, { useState, useEffect } from 'react';
import { Grade, UserRole, LessonContent, UserProfile, TopicProgress } from './types';
import { generateMathContent } from './geminiService';
import LessonView from './components/LessonView';
import { 
  Book, GraduationCap, Star, Search, Sparkles, AlertCircle, 
  Loader2, Home, Layout, Users, Settings, UserCircle, 
  Award, TrendingUp, Clock, ChevronRight, Camera, Target
} from 'lucide-react';

const INITIAL_PROFILE: UserProfile = {
  name: "Budi Santoso",
  role: 'STUDENT',
  points: 1250,
  level: 5,
  badges: ['Pemula Cerdas', 'Pecinta Aljabar'],
  progress: [
    { topicId: '1', title: 'Perbandingan Berbalik Nilai', grade: 'SMP', status: 'COMPLETED', score: 90 },
    { topicId: '2', title: 'Pecahan Senilai', grade: 'SD', status: 'IN_PROGRESS' },
    { topicId: '3', title: 'Bangun Datar', grade: 'SD', status: 'LOCKED' },
  ]
};

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('math_pintar_user');
    return saved ? JSON.parse(saved) : INITIAL_PROFILE;
  });
  
  // Hash-based routing state
  const [activeTab, setActiveTab] = useState<'HOME' | 'LEARN' | 'LEADERBOARD' | 'PROFILE'>('HOME');
  const [lessonContent, setLessonContent] = useState<LessonContent | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTopic, setSearchTopic] = useState('');
  const [selectedGrade, setSelectedGrade] = useState<Grade>('SD');

  // Sync state with URL hash
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').toUpperCase();
      if (['HOME', 'LEARN', 'LEADERBOARD', 'PROFILE'].includes(hash)) {
        setActiveTab(hash as any);
      } else if (!window.location.hash) {
        window.location.hash = '#home';
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Initialize on mount

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  useEffect(() => {
    localStorage.setItem('math_pintar_user', JSON.stringify(user));
  }, [user]);

  const navigateTo = (tab: string) => {
    window.location.hash = tab.toLowerCase();
  };

  const startLesson = async (grade: Grade, level: string, topic: string) => {
    setLoading(true);
    setError(null);
    try {
      const context = "Siswa ingin belajar mandiri. Buat materi yang interaktif.";
      const content = await generateMathContent(grade, level, topic, context);
      setLessonContent(content);
    } catch (err) {
      setError("Gagal memuat materi. Pastikan koneksi internet stabil.");
    } finally {
      setLoading(false);
    }
  };

  const handleLessonComplete = () => {
    setUser(prev => ({
      ...prev,
      points: prev.points + 200,
      level: Math.floor((prev.points + 200) / 500) + 1
    }));
    setLessonContent(null);
    navigateTo('HOME');
  };

  const renderStudentDashboard = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <section className="bg-gradient-to-br from-indigo-600 to-purple-700 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 blur-2xl"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <h2 className="text-3xl font-black mb-2">Halo, {user.name}! 👋</h2>
            <p className="text-indigo-100 font-medium">Siap menaklukkan tantangan matematika hari ini?</p>
            <div className="mt-6 flex gap-3">
               <div className="bg-white/20 px-4 py-2 rounded-xl backdrop-blur-md flex items-center gap-2">
                 <Star className="text-yellow-400 fill-yellow-400" size={18} />
                 <span className="font-bold">{user.points} XP</span>
               </div>
               <div className="bg-white/20 px-4 py-2 rounded-xl backdrop-blur-md flex items-center gap-2">
                 <Award className="text-emerald-300" size={18} />
                 <span className="font-bold">Level {user.level}</span>
               </div>
            </div>
          </div>
          <div className="bg-white/10 p-4 rounded-3xl backdrop-blur-sm border border-white/20">
             <div className="text-xs font-bold uppercase tracking-widest text-indigo-200 mb-2">Progres Level</div>
             <div className="w-48 h-3 bg-indigo-900/50 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.5)]"
                  style={{ width: `${(user.points % 500) / 5}%` }}
                ></div>
             </div>
          </div>
        </div>
      </section>

      <section className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
        <h3 className="text-xl font-black text-gray-900 mb-6 flex items-center gap-2">
          <Sparkles className="text-indigo-500" /> Tanya AI "Mesin Pemahaman"
        </h3>
        <div className="flex gap-2 mb-4">
           {(['SD', 'SMP', 'SMA'] as Grade[]).map(g => (
             <button 
                key={g}
                onClick={() => setSelectedGrade(g)}
                className={`flex-1 py-3 rounded-2xl font-bold transition-all ${selectedGrade === g ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 text-slate-500'}`}
             >
               {g}
             </button>
           ))}
        </div>
        <div className="relative group">
          <input 
            type="text" 
            placeholder="Cari topik (ex: Aljabar Dasar, Perkalian)..."
            className="w-full p-5 pl-14 bg-slate-50 border-2 border-slate-100 rounded-3xl focus:border-indigo-400 focus:bg-white outline-none transition-all"
            value={searchTopic}
            onChange={(e) => setSearchTopic(e.target.value)}
          />
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
          <button 
            onClick={() => startLesson(selectedGrade, "Level Sesuai", searchTopic)}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-indigo-600 p-3 rounded-2xl text-white hover:bg-indigo-700 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-black text-gray-900">Lanjutkan Belajarmu</h3>
          <button onClick={() => navigateTo('LEARN')} className="text-sm font-bold text-indigo-600 hover:underline">Lihat Semua</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {user.progress.filter(p => p.status !== 'LOCKED').map((topic, i) => (
            <div 
              key={i}
              className="group bg-white p-6 rounded-[2rem] border border-slate-100 hover:border-indigo-200 hover:shadow-xl transition-all cursor-pointer"
              onClick={() => startLesson(topic.grade, "Sesuai Kurikulum", topic.title)}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="h-12 w-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-500">
                   <Book size={24} />
                </div>
                <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${topic.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                  {topic.status === 'COMPLETED' ? 'Selesai' : 'Sedang Belajar'}
                </span>
              </div>
              <h4 className="text-lg font-extrabold text-gray-900 group-hover:text-indigo-600 transition-colors">{topic.title}</h4>
              <p className="text-slate-400 text-sm mt-1">{topic.grade} • Matematika Pintar</p>
              {topic.score && (
                <div className="mt-4 flex items-center gap-2">
                   <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-400" style={{ width: `${topic.score}%` }}></div>
                   </div>
                   <span className="text-xs font-bold text-slate-500">{topic.score}%</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );

  const renderTeacherDashboard = () => (
    <div className="space-y-8 animate-in slide-in-from-left-4 duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Analisis Kelas VII-A</h2>
          <p className="text-slate-500">Pantau perkembangan pemahaman siswa secara real-time.</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
           <Users className="text-indigo-500" />
           <div>
             <div className="text-xs font-bold text-slate-400 uppercase">Total Siswa</div>
             <div className="text-xl font-black">32 Siswa</div>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100">
           <TrendingUp className="text-emerald-500 mb-4" />
           <h4 className="font-bold text-slate-900">Rata-rata Skor</h4>
           <p className="text-4xl font-black text-emerald-600 mt-2">84.5</p>
           <p className="text-xs text-slate-400 mt-1">↑ 5% dari minggu lalu</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100">
           <Clock className="text-amber-500 mb-4" />
           <h4 className="font-bold text-slate-900">Waktu Belajar</h4>
           <p className="text-4xl font-black text-amber-600 mt-2">42 Menit</p>
           <p className="text-xs text-slate-400 mt-1">Rata-rata per hari/siswa</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100">
           <AlertCircle className="text-rose-500 mb-4" />
           <h4 className="font-bold text-slate-900">Miskonsepsi Umum</h4>
           <p className="text-lg font-extrabold text-rose-600 mt-2">Operasi Pecahan</p>
           <p className="text-xs text-slate-400 mt-1">8 siswa kesulitan di sini</p>
        </div>
      </div>

      <div className="bg-indigo-900 text-white p-8 rounded-[2.5rem]">
         <h3 className="text-xl font-black mb-4 flex items-center gap-2">
           <Sparkles className="text-amber-400" /> Rekomendasi Pengajaran AI
         </h3>
         <p className="text-indigo-100 leading-relaxed mb-6">
           "Berdasarkan data minggu ini, sebagian besar siswa Anda mengalami kesulitan pada konsep **Pecahan Campuran**. Kami merekomendasikan sesi penguatan menggunakan analogi 'Potongan Kue' dan visualisasi interaktif pada pertemuan berikutnya."
         </p>
         <button className="bg-white text-indigo-900 px-6 py-3 rounded-2xl font-bold hover:bg-indigo-50 transition-colors">
            Unduh Materi Pengayaan
         </button>
      </div>
    </div>
  );

  const renderParentDashboard = () => (
    <div className="space-y-8 animate-in zoom-in duration-500">
       <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 flex items-center gap-6">
          <div className="h-24 w-24 bg-amber-100 rounded-full flex items-center justify-center border-4 border-amber-50">
             <UserCircle size={60} className="text-amber-500" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-slate-900">Pantau Budi Santoso</h2>
            <p className="text-slate-500">Laporan Mingguan: 12 - 18 Mei 2024</p>
            <div className="mt-3 flex gap-2">
               <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black px-3 py-1 rounded-full uppercase">Sangat Aktif</span>
               <span className="bg-indigo-100 text-indigo-700 text-[10px] font-black px-3 py-1 rounded-full uppercase">Paham Konsep Aljabar</span>
            </div>
          </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100">
             <h3 className="text-lg font-black mb-6">Pencapaian Baru</h3>
             <div className="space-y-4">
                <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl">
                   <Award className="text-yellow-500" />
                   <div>
                      <div className="font-bold">Ahli Perbandingan</div>
                      <div className="text-xs text-slate-400">Menyelesaikan 5 materi tanpa salah kuis.</div>
                   </div>
                </div>
                <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl opacity-50">
                   <Target className="text-indigo-300" />
                   <div>
                      <div className="font-bold text-slate-400">Raja Geometri</div>
                      <div className="text-xs text-slate-400">Selesaikan materi Bangun Ruang untuk buka.</div>
                   </div>
                </div>
             </div>
          </div>
          <div className="bg-indigo-50 p-8 rounded-[2.5rem] border border-indigo-100">
             <h3 className="text-lg font-black text-indigo-900 mb-2">Tips Dukungan Orang Tua</h3>
             <p className="text-indigo-800/70 text-sm mb-4">
               Budi baru saja menyelesaikan materi "Pecahan". Cobalah minta Budi membantu membagi makanan saat makan malam untuk memperkuat pemahamannya!
             </p>
             <button className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200">
                Kirim Apresiasi ke Budi ❤️
             </button>
          </div>
       </div>
    </div>
  );

  const renderContent = () => {
    if (loading) return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="relative h-24 w-24 mb-6">
           <div className="absolute inset-0 border-8 border-indigo-100 rounded-full"></div>
           <div className="absolute inset-0 border-8 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
        </div>
        <h2 className="text-xl font-black text-indigo-900">Menyusun Mesin Pemahaman...</h2>
        <p className="text-slate-400 text-center max-w-xs mt-2">AI sedang membuat materi yang paling cocok untuk kamu.</p>
      </div>
    );

    if (activeTab === 'HOME') {
      if (user.role === 'STUDENT') return renderStudentDashboard();
      if (user.role === 'TEACHER') return renderTeacherDashboard();
      if (user.role === 'PARENT') return renderParentDashboard();
    }
    
    // Placeholder for other routes
    const routeTitles: Record<string, string> = {
      LEARN: 'Materi Belajar',
      LEADERBOARD: 'Papan Peringkat',
      PROFILE: 'Profil Pengguna'
    };

    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white rounded-[3rem] border border-dashed border-slate-200">
        <Layout size={64} className="mb-4 opacity-20" />
        <h2 className="text-2xl font-black text-slate-600 mb-2">{routeTitles[activeTab]}</h2>
        <p className="font-bold text-lg">Halaman sedang dalam tahap pengembangan akhir...</p>
        <button 
          onClick={() => navigateTo('HOME')}
          className="mt-6 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-100"
        >
          Kembali ke Beranda
        </button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      
      {/* Role Switcher (Simulator Only) */}
      <div className="fixed top-4 right-4 z-50 flex gap-2">
        {(['STUDENT', 'TEACHER', 'PARENT'] as UserRole[]).map(r => (
          <button 
            key={r}
            onClick={() => setUser(prev => ({ ...prev, role: r }))}
            className={`px-3 py-1 rounded-full text-[10px] font-black border-2 transition-all ${user.role === r ? 'bg-black text-white border-black' : 'bg-white text-black border-slate-200'}`}
          >
            {r === 'STUDENT' ? 'Siswa' : r === 'TEACHER' ? 'Guru' : 'Ortu'}
          </button>
        ))}
      </div>

      {/* Sidebar Desktop */}
      <aside className="hidden md:flex w-72 h-screen sticky top-0 bg-white border-r border-slate-100 flex-col p-8 shrink-0">
         <div className="flex items-center gap-3 mb-12">
            <div className="math-gradient p-2 rounded-xl text-white">
               <GraduationCap size={28} />
            </div>
            <h1 className="text-xl font-black text-slate-900 tracking-tighter">Matematika Pintar</h1>
         </div>

         <nav className="space-y-2 flex-1">
            <NavItem icon={Home} label="Beranda" active={activeTab === 'HOME'} onClick={() => navigateTo('HOME')} />
            <NavItem icon={Book} label="Materi Belajar" active={activeTab === 'LEARN'} onClick={() => navigateTo('LEARN')} />
            <NavItem icon={Award} label="Leaderboard" active={activeTab === 'LEADERBOARD'} onClick={() => navigateTo('LEADERBOARD')} />
            <NavItem icon={UserCircle} label="Profil Saya" active={activeTab === 'PROFILE'} onClick={() => navigateTo('PROFILE')} />
         </nav>

         <div className="mt-auto space-y-4 pt-8 border-t border-slate-50">
            <div className="bg-slate-50 p-4 rounded-2xl flex items-center gap-3">
               <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-black">BS</div>
               <div className="overflow-hidden">
                  <div className="text-sm font-bold text-slate-900 truncate">{user.name}</div>
                  <div className="text-[10px] text-slate-400 font-bold uppercase">{user.role}</div>
               </div>
            </div>
            <button className="w-full py-3 text-slate-400 hover:text-rose-500 font-bold text-sm flex items-center gap-3 transition-colors px-4">
               <Settings size={18} /> Pengaturan
            </button>
         </div>
      </aside>

      {/* Main Container */}
      {lessonContent ? (
        <div className="flex-1 p-4 md:p-12 overflow-y-auto">
          <LessonView content={lessonContent} onComplete={handleLessonComplete} />
        </div>
      ) : (
        <main className="flex-1 overflow-y-auto p-4 md:p-12 pb-32 md:pb-12">
           <div className="max-w-5xl mx-auto">
              {renderContent()}
           </div>
        </main>
      )}

      {/* Bottom Nav Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-slate-100 flex justify-around p-4 z-40">
        <button onClick={() => navigateTo('HOME')} className={`p-2 rounded-2xl transition-colors ${activeTab === 'HOME' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
           <Home size={24} />
        </button>
        <button onClick={() => navigateTo('LEARN')} className={`p-2 rounded-2xl transition-colors ${activeTab === 'LEARN' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
           <Book size={24} />
        </button>
        <button className="bg-indigo-600 p-4 rounded-full text-white -mt-10 shadow-xl shadow-indigo-200 border-4 border-slate-50 active:scale-95 transition-transform">
           <Camera size={24} />
        </button>
        <button onClick={() => navigateTo('LEADERBOARD')} className={`p-2 rounded-2xl transition-colors ${activeTab === 'LEADERBOARD' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
           <Award size={24} />
        </button>
        <button onClick={() => navigateTo('PROFILE')} className={`p-2 rounded-2xl transition-colors ${activeTab === 'PROFILE' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
           <UserCircle size={24} />
        </button>
      </nav>
    </div>
  );
};

const NavItem: React.FC<{ icon: any, label: string, active?: boolean, onClick: () => void }> = ({ icon: Icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl font-bold transition-all ${active ? 'bg-indigo-50 text-indigo-600 shadow-sm' : 'text-slate-400 hover:bg-slate-50 hover:text-slate-600'}`}
  >
    <Icon size={20} />
    <span className="text-sm">{label}</span>
  </button>
);

export default App;
