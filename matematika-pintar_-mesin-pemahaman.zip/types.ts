
export type Grade = 'SD' | 'SMP' | 'SMA';
export type UserRole = 'STUDENT' | 'TEACHER' | 'PARENT';

export interface LessonContent {
  title: string;
  grade: Grade;
  classLevel: string;
  contextualStory: {
    story: string;
    triggerQuestion: string;
  };
  coreConcept: {
    explanation: string[];
    analogy: string;
  };
  visualDescription: string;
  formula: {
    latex: string;
    explanation: string;
    whenToUse: string;
  };
  examples: Array<{
    difficulty: 'Mudah' | 'Sedang' | 'Menantang';
    question: string;
    steps: string[];
  }>;
  commonErrors: Array<{
    error: string;
    reason: string;
    solution: string;
  }>;
  adaptiveQuiz: Array<{
    level: 'Mudah' | 'Sedang' | 'Sulit';
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }>;
  miniGame: {
    name: string;
    concept: string;
    rules: string;
    gameplay: string;
  };
  reflection: {
    summary: string[];
    keyPoints: string[];
    motivation: string;
  };
}

export interface TopicProgress {
  topicId: string;
  title: string;
  grade: Grade;
  status: 'LOCKED' | 'IN_PROGRESS' | 'COMPLETED';
  score?: number;
}

export interface UserProfile {
  name: string;
  role: UserRole;
  points: number;
  level: number;
  badges: string[];
  progress: TopicProgress[];
}
